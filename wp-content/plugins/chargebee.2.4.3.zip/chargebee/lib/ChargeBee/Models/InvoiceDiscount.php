<?php

class ChargeBee_InvoiceDiscount extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description', 'type', 'entity_id');

}

?>