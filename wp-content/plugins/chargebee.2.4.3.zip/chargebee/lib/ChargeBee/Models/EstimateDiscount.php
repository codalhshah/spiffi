<?php

class ChargeBee_EstimateDiscount extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description', 'type', 'entity_id');

}

?>