<?php

class ChargeBee_EventWebhook extends ChargeBee_Model
{
  protected $allowed = array('id', 'webhook_status');

}

?>