<?php

class ChargeBee_InvoiceNote extends ChargeBee_Model
{
  protected $allowed = array('entity_type', 'note', 'entity_id');

}

?>