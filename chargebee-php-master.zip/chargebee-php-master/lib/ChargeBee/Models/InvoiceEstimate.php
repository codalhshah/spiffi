<?php

class ChargeBee_InvoiceEstimate extends ChargeBee_Model
{

  protected $allowed = array('recurring', 'priceType', 'currencyCode', 'subTotal', 'total', 'creditsApplied',
'amountPaid', 'amountDue', 'lineItems', 'discounts', 'taxes', 'lineItemTaxes');



  # OPERATIONS
  #-----------

 }

?>