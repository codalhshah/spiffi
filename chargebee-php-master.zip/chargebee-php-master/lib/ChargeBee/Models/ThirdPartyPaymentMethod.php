<?php

class ChargeBee_ThirdPartyPaymentMethod extends ChargeBee_Model
{

  protected $allowed = array('type', 'gateway', 'referenceId'
);



  # OPERATIONS
  #-----------

 }

?>