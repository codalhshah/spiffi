<?php

class ChargeBee_SubscriptionEstimate extends ChargeBee_Model
{

  protected $allowed = array('id', 'currencyCode', 'status', 'nextBillingAt', 'shippingAddress'
);



  # OPERATIONS
  #-----------

 }

?>