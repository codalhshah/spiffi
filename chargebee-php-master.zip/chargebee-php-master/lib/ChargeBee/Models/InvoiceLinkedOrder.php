<?php

class ChargeBee_InvoiceLinkedOrder extends ChargeBee_Model
{
  protected $allowed = array('id', 'status', 'reference_id', 'fulfillment_status', 'batch_id', 'created_at');

}

?>