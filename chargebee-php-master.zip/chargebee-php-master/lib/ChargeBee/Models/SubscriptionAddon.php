<?php

class ChargeBee_SubscriptionAddon extends ChargeBee_Model
{
  protected $allowed = array('id', 'quantity');

}

?>