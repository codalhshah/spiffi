<?php

class ChargeBee_CreditNoteEstimateDiscount extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description', 'entity_type', 'entity_id');

}

?>