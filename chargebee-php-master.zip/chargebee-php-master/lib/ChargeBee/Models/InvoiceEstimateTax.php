<?php

class ChargeBee_InvoiceEstimateTax extends ChargeBee_Model
{
  protected $allowed = array('name', 'amount', 'description');

}

?>