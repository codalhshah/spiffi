<?php

class ChargeBee_InvoiceEstimateDiscount extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description', 'entity_type', 'entity_id');

}

?>