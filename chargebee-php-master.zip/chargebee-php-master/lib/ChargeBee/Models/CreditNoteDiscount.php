<?php

class ChargeBee_CreditNoteDiscount extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description', 'entity_type', 'entity_id');

}

?>