<?php

class ChargeBee_InvoiceDiscount extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description', 'entity_type', 'entity_id');

}

?>