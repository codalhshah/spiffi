<?php

class ChargeBee_CreditNoteTax extends ChargeBee_Model
{
  protected $allowed = array('name', 'amount', 'description');

}

?>