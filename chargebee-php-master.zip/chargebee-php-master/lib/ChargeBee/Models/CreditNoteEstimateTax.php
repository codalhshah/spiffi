<?php

class ChargeBee_CreditNoteEstimateTax extends ChargeBee_Model
{
  protected $allowed = array('name', 'amount', 'description');

}

?>