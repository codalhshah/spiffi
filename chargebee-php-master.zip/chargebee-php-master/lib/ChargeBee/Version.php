<?php

final class ChargeBee_Version
{
	  const VERSION = '2.1.3';
}

?>
